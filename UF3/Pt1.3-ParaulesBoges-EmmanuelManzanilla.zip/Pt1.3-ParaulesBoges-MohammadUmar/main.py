﻿"""
Umar Mohammad Riaz & Emmanuel Manzanilla
04/05/2022
ASIXc 1B

Runs the program
"""
import os.path
from crazyWords import paraulesBoges

inputFolder = "entrada"     # Ruta de la carpeta d'entrada

paraulesBoges(os.path.join(".", inputFolder))  # Converteix en ruta relativa i exxecuta