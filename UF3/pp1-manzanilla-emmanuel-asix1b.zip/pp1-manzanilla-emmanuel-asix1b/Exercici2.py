'''
Emmanuel Manzanilla García
17/05/2022

ASIXb M03 Fonaments de Gestió de Fitxers

Exercici 3

'''

#TO DO

