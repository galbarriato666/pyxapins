"""
Emmanuel Manzanilla García
1r ASIXcB - A5 + Pp3 - Exercici1
01/02/2022

"""
qty = 10
llista = []
suma = 0

for word in range(qty, 0, -1):
    llista.append(str(input(f"{word} paraula!: ")))

print(llista)

big_paraula = llista[0]
small_paraula = llista[0]

mides = [llista[0], llista[0]]

for paraules in (llista):
    tamanyP = len(paraules)
    suma += tamanyP

    if tamanyP > len(big_paraula):
        mides[0] = paraules
    elif tamanyP < len(mides[0]):
        mides[1] = paraules

print(f'La paraula + llarga és = {big_paraula}')
print(f"La paraula + curta és = {small_paraula}")
print(f'La mitja de les paraules introduides és = {round(suma / len(llista), 2)}')
